# Flappy Bird Clone - Unity Mobile Game(Flappy Parrot Flying)

This is a Flappy Bird style mobile game that i have made on unity for a freelance, in fact this was the first game that i've ever made and 
earned money with it. No...i didn't chose the weird name that this game currently have and YES...i want to change it in the future.

You are allowed to modify/use/sell this game in anyway that you want, i just ask you to credit me.

## Some Remarks About This Project/Repository

I do intend to update this game eventually, make some better graphics, improve the UI, add some features, some new content and
fix the messy code.

And of course, i will keep it open-source and free for commercial use, but i am currently stuck on a bigger project and i don't have
much time to work on this project.


## About The Game

I didn't really know what i was doing back in the day when i was hired to do this game, so as you can see, some images are streched and i
didn't know how to use photoshop properly (as you can see in the screenshots below), and the code...the code was a mess, it was all 
over the place.

## Screenshots

<div>
  <img width="251" height="447" align="left" src="https://github.com/NicolasPCouts/FlappyBird-Unity2017/blob/master/screenshots/Screenshot_20180710-001753.png">
  <img width="251" height="447" align="left" src="https://github.com/NicolasPCouts/FlappyBird-Unity2017/blob/master/screenshots/Screenshot_20180710-001807.png">
    <img width="251" height="447" align="left" src="https://github.com/NicolasPCouts/FlappyBird-Unity2017/blob/master/screenshots/Screenshot_20180710-001911.png">
</div>
